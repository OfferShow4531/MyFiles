fun main() {
    Task1(2,10)
    Task2(5)
    Task3()
    Task4()
    Task5()
}

//pow
fun Task1(a:Int, n: Int) {
    var result = 1
    for (i in 0..n) {
        result = a*result
    }
    println("Task 1: " + result)
}

//factorial
fun Task2(n: Int) {
    var result: Long = 1
    for (i in 1..n) {
        result *= i
    }
    println("Task 2: " + result)
}

//min from 10 nums
fun Task3() {
    val array = arrayOf(1,21,64,56,78,32,46,67,43,15)
    var min = array[0]
    for (number in array) {
        if (number < min)
            min = number
    }
    println("Task 3: " + min)
}

//avrg sum of the array
fun Task4() {
    val array = arrayOf(1,2,3,4,5,6,7,1)
    var result : Double = 0.0
    for (number in array) {
        result += number
    }
    result = result/array.size
    println("Task 4: " + result)
}

//max-min
fun Task5() {
	val array = arrayOf(1,2,3,4,5,6,7,1)
    var result = 0
    var min = array[0]
    var max = array[0]
    for (number in array) {
        if (number < min)
            min = number
        if (number > max) 
        	max = number
    }
    result = max-min
    println("Task 5: " + result)
}
