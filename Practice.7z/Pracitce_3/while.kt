fun main() {
    Task1(2,10)
    Task2(5)
    Task3(10)
    Task4(2)
    Task5()
}
// pow()
fun Task1(A: Int, N: Int) {
    var result = 1
    var count = 0
    while (count <= N) {
        result = A * result
        count++ 
    }
    println("Task 1: " + result)
}

//factorial
fun Task2(N: Int) {
    var result : Long = 1
    var count = 1
    while (count <= N) {
        result = result * count
        count++
    }
    println("Task 2: " + result)
}

//fibonacci
fun Task3(N: Int) {
    var t1 = 0
    var t2 = 1
    var count = 1
    print("Task 3: ")
    while (count <= N) {
        print("$t1 ")
        val sum = t1+t2
        t1 = t2
        t2 = sum
        count++
    }
    println()
}

//summa kvadratov
fun Task4(N: Int) {
    var result = 0.0
    var counter = 1
    while (counter <= N) {
        result += Math.pow(counter.toDouble(), 2.0)
        counter++
    }
    println("Task 4: " + result.toInt())
}

//summa vvoda
fun Task5() {
    var num = 1
    var sum = 0
    while(num != 0) {
        val inputString = readLine()!!
        num = inputString.toInt()
        sum += num
    }
    println("Task 5: " + sum)
}