fun main() {
    //mutable list
    val nums = mutableListOf(-5,8,6,-9,3)
    val result = sort(nums)
    for (i in result)
    	println(i)
    println("\n\n")
    //list
    val nums1 = arrayOf(-5,8,6,-9,3)
    val result1 = sort(nums1)
    for (i in result1)
    	println(i)
	println("\n\n")
    //vararg
    val result3 = sort(-5,8,6,-9,3)
    for (i in result1)
    	println(i)
		
		
	//SECOND LESSON
	println(capacity(1,2,3))
    println(capacity(3))
    println(capacity(2,3))
	
	//THIRD LESSON
	println(sum("1","qew"))
}

//FIRST LESSON ABOUT FUNS
//RETURN SORTED LIST
fun sort(nums: MutableList<Int>): List<Int> {
    for (i in 1 until nums.size) {
        for (j in nums.size - 1 downTo i) {
            if (nums[j]<nums[j-1]) {
                val temp = nums[j]
                nums[j] = nums[j-1]
                nums[j-1] = temp
            }
        }
    }
    return nums
}

//override
fun sort(nums: Array<Int>) = sort(nums.toMutableList())
fun sort(vararg nums: Int) = sort(nums.toMutableList())


// SECOND LESSON ABOUT DEFAULT AND NAMED PARAMETRES
// HOMEWORK RETURN CAPACUTY OF PARALLELEPIPED
fun capacity(a: Int, b: Int = a, c: Int = a) = a*b*c

//THIRD LESSON ABOUT WITHOUT HOMEWORK
fun sum(a: String, b: String): Int {
    return try {
        val numA = a.toInt()
    	val numB = b.toInt()
    	numA+numB
    } catch (e: Exception) {
        0
    }
}