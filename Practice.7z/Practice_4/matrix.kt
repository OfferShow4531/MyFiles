fun main() {
    Task1()
    Task2()
    Task3()
    Task4()
    Task5()
}

//replace nechetnie rows on array
fun Task1() {
	val size = 6
    val matrix = arrayOf(IntArray(size), IntArray(size), IntArray(size), IntArray(size), IntArray(size), IntArray(size))
    val array = IntArray(size) { kotlin.random.Random.nextInt(-10,10)}
    for (row in 0..size-1) {
        for (column in 0..size-1) {
            matrix[row][column] = kotlin.random.Random.nextInt(-10,10)
        }
    }
	//working
    for (row in 0..size-1) {
        for (column in 0..size-1) {
            if (row%2!=0) {
                matrix[row][column] = array[column] 
            }
        }
    }
    //printing
    println("TASK 1: ")
    for (row in 0..size-1) {
        for (column in 0..size-1) {
            print("" + matrix[row][column] + "\t")
        }
       	println()
    }
}

//replace nechetnie rows on array
fun Task2() {
	val size = 6
    val matrix = arrayOf(IntArray(size), IntArray(size), IntArray(size), IntArray(size), IntArray(size), IntArray(size))
    val array = IntArray(size) { kotlin.random.Random.nextInt(-10,10)}
    for (row in 0..size-1) {
        for (column in 0..size-1) {
            matrix[row][column] = kotlin.random.Random.nextInt(-10,10)
        }
    }
	//working
    for (row in 0..size-1) {
        for (column in 0..size-1) {
            if (row%2==0) {
                matrix[row][column] = array[column] 
            }
        }
    }
    //printing
    println("TASK 2: ")
    for (row in 0..size-1) {
        for (column in 0..size-1) {
            print("" + matrix[row][column] + "\t")
        }
       	println()
    }
}

//replace first three lines on X array
fun Task3() {
	val size = 6
    val matrix = arrayOf(IntArray(size), IntArray(size), IntArray(size), IntArray(size), IntArray(size), IntArray(size))
    val array = IntArray(size) { kotlin.random.Random.nextInt(-10,10)}
    for (row in 0..size-1) {
        for (column in 0..size-1) {
            matrix[row][column] = kotlin.random.Random.nextInt(-10,10)
        }
    }
	//working
    for (row in 0..3-1) {
        for (column in 0..size-1) {
			matrix[row][column] = array[column] 
        }
    }
    //printing
    println("TASK 3: ")
    for (row in 0..size-1) {
        for (column in 0..size-1) {
            print("" + matrix[row][column] + "\t")
        }
       	println()
    }
}

//min and max in the matrix
fun Task4() {
	val size = 6
    val matrix = arrayOf(IntArray(size), IntArray(size), IntArray(size), IntArray(size), IntArray(size), IntArray(size))
    val array = IntArray(size) { kotlin.random.Random.nextInt(-10,10)}
    for (row in 0..size-1) {
        for (column in 0..size-1) {
            matrix[row][column] = kotlin.random.Random.nextInt(-10,10)
        }
    }
	//working
	var max = matrix[0][0]
    var min = matrix[0][0]
    var imin = 0
    var jmin = 0
    var imax = 0
    var jmax = 0
    for (row in 0..3-1) {
        for (column in 0..size-1) {
			if (matrix[row][column]<min) {
				min = matrix[row][column]
                imin = row
                jmin = column
            } else if (matrix[row][column]>max) {
                max = matrix[row][column]
                imax = row
                jmax = row
            }
        }
    }
    //printing
    println("TASK 4: " + min + " " + "Indexes: " + imin + " " + jmin)
    println("TASK 4: " + max + " " + "Indexes: " + imax + " " + jmax)
}

//b[i][j] = a[i] - 3a[j]
fun Task5() {
	val size = 3
    val matrix = arrayOf(IntArray(size), IntArray(size), IntArray(size))
    val array = arrayOf(4,5,6)
	//working
    for (i in 0..size-1) {
        for (j in 0..size-1) {
			matrix[i][j] = array[i]-3*array[j]
        }
    }
    //printing
    println("TASK 5: ")
    for (row in 0..size-1) {
        for (column in 0..size-1) {
            print("" + matrix[row][column] + "\t")
        }
       	println()
    }
}
