НУ fun main() {
    Task1()
    Task2()
    Task3()
    Task4()
    Task5()
}

//max and index from array
fun Task1() {
    var array  = IntArray(15) { java.util.Random().nextInt() }.asList()
    var max = array[0]
    for (num in array)
        if (num>max)
        	max = num
    println("Task 1: " + max + " " + array.indexOf(max))
}

//min and index from array
fun Task2() {
    var array  = IntArray(15) { java.util.Random().nextInt() }.asList()
    var min = array[0]
    for (num in array)
        if (num<min)
        	min = num
    println("Task 2: " + min + " " + array.indexOf(min))
}

//find first negative number and index
fun Task3() {
    var array  = IntArray(15) { java.util.Random().nextInt() }.asList()
    var check = false
    for (num in array) {
        if (num<0) {
            check = true
            println("Task 3: " + num + " " + array.indexOf(num))
            break;
        }
    }
    if (check == false)
        println("Task 4: there is no negative elements")
}

//find zero
fun Task4() {
    var array  = IntArray(15) { java.util.Random().nextInt() }.asList()
    var check = false
    for (num in array) {
        if (num==0) {
            check = true
            println("Task 4: " + array.indexOf(num))
            break;
        }
    }
    if (check == false)
        println("Task 4: there is no zero elements")
}

//count num>3 elements
fun Task5() {
    var array  = IntArray(15) { java.util.Random().nextInt() }.asList()
    var count = 0
    for (num in array)
        if (num>3)
            count++
    println("Task 5: " + count)
}