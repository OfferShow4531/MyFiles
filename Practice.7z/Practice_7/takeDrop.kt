// lazy seq
fun main() {
	val array = generateSequence("Сотрудник №1") {
        val index = it.substring(11).toInt()
        "Сотрудник #${index+1}"
    }
    val list = array.take(100)
    for (i in list) {
        println(i)
    }
}
 