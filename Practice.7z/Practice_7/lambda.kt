// LAMBDA
fun main() {
	// first is find a pow of 2
    val square: (Int) -> Int = { a -> a*a }
    println(square(2))
    
    //second perimetr
    val per: (Int, Int) -> Int = { a, b -> (a+b)*2 }
    println(per(1,2))
    
    //third print hello, name
    val printName: (String) -> Unit = { println("Hello, $it!") }
    println(printName("Vlada"))
    
    //fourth sort array
    val sortDesc: (Array<Int>) -> Array<Int> = {
        it.sortedArrayDescending()
    }
    val sortedArray = sortDesc(arrayOf(1,6,8,0,-5,))
    for (i in sortedArray) {
        println(i)
    }
}