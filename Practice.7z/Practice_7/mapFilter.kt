// MAP and FILTER
fun main() {
	// first is names with T first
	val names = listOf("Masha", "Tamik", "Vlada", "Era", "Ramen", "Noname", "Forsaken World")
    val namesStartsFromT = names.filter {it.startsWith("T")}
    for (i in namesStartsFromT) {
        println(i)
    }
    
    // second random array with 1000 elements
    val array = mutableListOf<Int>()
    for (i in 0 until 1000) {
        array.add((Math.random()*1000).toInt())
    }
    
    //third nums%5 and %3;
    //fourth is square
    //fifth sort desc
    //sixth is toString
    val result = array.filter { it%5 == 0 || it%3 == 0 }. map { it*it }.sortedDescending().map { "$it" }
    
    for (i in result) {
        println(i)
    }
}
 