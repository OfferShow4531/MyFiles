// ZIP
fun main() {
    // name + phone
// 	val name = mutableListOf<String>()
//     val phones = mutableListOf<Long>()
//     for (i in 0..1000) {
//         name.add("Name$i")
//         phones.add(8_000_000_000_0 + (Math.random()* 2_000_000_000).toLong())
//     }
//     val users = name.zip(phones)
// 	for (users in users) {
//         println("Name: ${users.first} Phone: ${users.second}")
//     }
    
    
    // name + second name
    val fullName = mutableListOf<String>()
    for (i in 0..1000) {
        fullName.add("Name$i Surname$i")
    }
    val names = fullName.map { it.substringBefore(" ")}
    val surnames = fullName.map { it.substringAfter(" ")}
//     for (i in names) {
//         println(i)
//     }
//     for (i in surnames) {
//         println(i)
//     }
    
    val users = names.zip(surnames)
    for (user in users) {
        println("Name: ${user.first} Surname: ${user.second}")
    }
}
 