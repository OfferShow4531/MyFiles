fun TaskOne(x: Double, y: Double, z: Double) : Double {
    if (x>y && x>z) return x
    else if (y>x && y>z) return y
    else return z
}

fun TaskTwo(x: Double, y: Double, z: Double) : Double {
    if (x<y && x<z) return x
    else if (y<x && y<z) return y
    else return z
}

fun TaskThree(x: Double, y: Double, z: Double) {
    if (x>=y && y>=z)
        println("Task Three: " + x*2.0 + " " + y*2.0 + " " + z*2.0)
    else
        println("Task Three: " + Math.abs(x) + " " + Math.abs(y) + " " + Math.abs(z))
}

fun TaskFour(x: Double, y: Double) {
    if (x>y)
        println("Task Four: " + x)
    else
        println("Task Four: " + x + " " + y)
}

fun TaskFive() {
    var x = 122.0
    val y = 2.0
    if (x<=y) x=0.0
    println("Task Five: " + x)
}

fun TaskSix(x: Double, y: Double, z: Double) {
    print("Task Six:")
    if (x in 1.0..3.0) print(" " + x + " ")
    if (y in 1.0..3.0) print(" " + y + " ")
    if (z in 1.0..3.0) print(" " + z + " ")
    println()
}

fun TaskSeven() {
    var x = 4.0
    var y = 2.0
    val tempX = x
    val tempY = y
    if (x!=y) {
        if (x>y) {
            y = (tempX+tempY)/2.0
            x = tempX*tempY*2.0
            println("Task Seven: X is max: " + x + ", Y is min " + y)
        } else {
            x = (tempX+tempY)/2.0
            y = tempX*tempY*2.0
            println("Task Seven: Y is max: " + x + ", X is min " + y)
        }
    }
}

fun TaskEight() {
    var x = -1.0
    var y = 2.0
    var z = 3.0
    if (x>0.0) x = x*x
    if (y>0.0) y = y*y
    if (z>0.0) z = z*z
    println("Task Eight: " + x + " " + y + " " + z)
}

fun TaskNine() {
    val x = -1.0
    val y = 2.0
    if (x!=y) {
        if (x<0.0)
            println("Task Nine: X<0: " + Math.max(x,y))
        else
        	println("Task Nine: X>0: " + Math.min(x,y))
    }
}

fun TaskTen() {
    val x = 6.0
    val y = 4.0
    val r = 5.0
    val h = Math.sqrt(x*x+y*y)
    if (h>r) println("Task Ten: Точка не принадлежит окружности")
    else println("Task Ten: Точка принадлежит окружности")
}

fun Task11() {
    var a = 8.0
    var b = 11.0
    var c = 0.5
    var d = 135.0
    if (a<=b && b<=c && c<=d) {
        a=d
        b=d
        c=d
        println("Task Eleven: if A<=B<=C<=D: " + a)
    } else if (a>b && b>c && c>d) { //В задании написано '<', это опечатка?
            println("Task Eleven: if A>B>C>D: a=" + a + " b=" + b + " c=" + c + " d=" + d)
	} else {
		a=a*a
		b=b*b
	    c=c*c
        d=d*d
		println("Task Eleven: ELSE: a=" + a + " b=" + b + " c=" + c + " d=" + d)
    }
}

fun Task12() {
    var x = 56.0
    var y = 36.0
    if (x<0.0 && y<0.0) {
        x = Math.abs(x)
        y = Math.abs(y)
    } else if (x<0.0 || y<0.0) {
        x = x+0.5
        y = y+0.5
    } else if (x>0.0 && y>0.0 && x !in 0.5..2.0) {
        x = x/10
        y = y/10
    } else {
        x = x
        y = y
    }
    println("Task Twelve: " + "x=" + x + " y=" + y)
}

fun Task13() {
    val x = 3
    val y = 8
    val z = 14
    if (x+y>z && x+z>y && y+z>x)
    	println("Task 13: Треугольник существует")
	else
    	println("Task 13: Треугольник не существует")
}

fun Task14() {
    val a = 345.0
    val b = 4.0
    var r = 2.0
    var s = 5.0
    if (r==a%b || s==a%b)
    	println("Task 14: YES")
	else
    	println("Task 15: NO")
}

fun Task15() {
    val n = 2
    if (n==1)
    	println("Task 15: " + n + " год")
    else if (n in 2..4)
    	println("Task 15: " + n + " года")
	else if (n in 5..20)
    	println("Task 15: " + n + " лет")
	else if (n%10 in 2..4)
    	println("Task 15: " + n + " года")
	else if (n%10==1)
    	println("Task 15: " + n + " год")
	else if (n%10 in 5..10)
    	println("Task 15: " + n + " лет")
}

fun Task16() {
    val x = 1.0
    var y: Double
    if (x in 0.0..2.0){
        y = Math.cos(x)
        y = y*y
        println("Task 16: y=cos^2(x): " + y)
    }
	else {
        y = Math.sin(x*x)
        y = 1-y
    	println("Task 16: y=1-sin(x^2): " + y)
    }
}

fun Task17() {
    var x = 0
    var y = 5
    var temp: Int
    if (x<y) {
        temp = x
        x = y
        y = temp
    }
    println("Task 17: x=" + x + " y=" + y)
}

fun Task18() {
    var k: Int
    var x = -1
    var y = 1
    if (x>0 && y>0) k = 1
    else if (x<0 && y>0) k = 2
    else if (x<0 && y<0) k = 3
    else k = 4
    println("Task 18: k=" + k)
}

fun Task19() {
    val n = 1901
    val c = (n-1)/100+1
    println(c)
}

fun Task20() {
	var a = 54245
    var b = 575757
    var c = 7
    var numbers: Array<Int> = arrayOf(a,b,c)
    numbers.sort()
    numbers.reverse()
    a = numbers[0]
    b = numbers[1]
    c = numbers[2]
    println("Task 20: " + a + " " + b + " " + c)
}

fun main() {
    println("Task One: " + TaskOne(1.0,2.0,3.0))
    println("Task Two: " + TaskTwo(1.0,2.0,3.0))
    TaskThree(-3.0,-2.0,-1.0)
    TaskFour(1.0,2.0)
    TaskFive()
    TaskSix(1.2, 2.0, 3.5)
    TaskSeven()
    TaskEight()
    TaskNine()
    TaskTen()
    Task11()
    Task12()
    Task13()
    Task14()
    Task15()
    Task16()
    Task17()
    Task18()
    Task19()
    Task20()
}