fun Task1(day : Int) {
    when(day) {
        1 -> println("Понедельник")
        2 -> println("Вторник")
        3 -> println("Среда")
        4 -> println("Четверг")
        5 -> println("Пятница")
        6 -> println("Суббота")
        7 -> println("Воскресенье")
        else -> {
            println("Error")
        }
    }
}

fun Task2(mon : Int) {
    when(mon) {
        1 -> println("Январь")
        2 -> println("Февраль")
        3 -> println("Март")
        4 -> println("Апрель")
        5 -> println("Май")
        6 -> println("Июнь")
        7 -> println("Июль")
        8 -> println("Август")
        9 -> println("Сентябрь")
        10 -> println("Октябрь")
        11 -> println("Ноябрь")
        12 -> println("Декабрь")
        else -> {
            println("Error")
        }
    }
}

fun Task3(point : Int) {
    when(point) {
        1 -> println("очень плохо")
        2 -> println("плохо")
        3 -> println("хорошо")
        4 -> println("очень хорошо")
        5 -> println("отлично")
        else -> {
            println("Error")
        }
    }
}

fun Task4(stud : Int) {
	when(stud) {
        
    }
}

fun Task5(note : Int) {
    when(note) {
        1 -> println("До")
        2 -> println("Ре")
        3 -> println("Ми")
        4 -> println("Фа")
        5 -> println("Соль")
        6 -> println("Ля")
        7 -> println("Си")
        8 -> println("До")
        else -> {
            println("Error")
        }
    }
}

fun Task6(day : Int) {
    when(day) {
        1 -> println(6)
        2 -> println(4)
        3 -> println(4)
        4 -> println(4)
        5 -> println(5)
        6 -> println(5)
        7 -> println(0)
        else -> {
            println("Error")
        }
    }
}

fun Task7(fourth : Int) {
    when(fourth)  {
        1 -> print("First: \n\tX: 0 <= x < +0\n\tY: 0 <= y < +0\n" )
        2 -> print("Second: \n\tX: -0 < x <= 0\n\tY: 0 <= y < +0\n" )
        3 -> print("Third: \n\tX: -0 < x <= 0\n\tY: -0 < y <= 0\n" )
        4 -> print("Fourth: \n\tX: 0 <= x < +0\n\tY: -0 < y <= 0\n" )
        else -> {
            println("Error")
        }
    }
}

fun Task8() {
    
}

fun Task9(month : Int, year : Int) {
    when (month) {
        1 -> println(31)
        2 -> if (year==1) println(29) else println(28)
        3 -> println(31)
        4 -> println(30)
        5 -> println(31)
        6 -> println(30)
        7 -> println(31)
        8 -> println(31)
        9 -> println(30)
        10 -> println(31)
        11 -> println(30)
        12 -> println(31)
        else -> {
            println("Error")
        }
    }
}

fun Task10(func : Int, op1 : Int, op2 : Int) {
    when (func) {
        1 -> println(op1+op2)
        2 -> println(op1-op2)
        3 -> println(op1*op2)
        4 -> println(op1/op2)
        else -> {
            println("Error")
        }
    }
}

fun main() {
    Task1(5)
    Task2(8)
    Task3(5)
    Task5(6)
    Task6(7)
    Task7(4)
    Task9(2, 0)
    Task10(3,4,5)
}